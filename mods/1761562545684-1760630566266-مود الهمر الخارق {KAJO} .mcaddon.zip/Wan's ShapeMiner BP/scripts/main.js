import { world, Player, system, EquipmentSlot, GameMode, ItemStack } from "@minecraft/server";
const ADDON_PREFIX = "§6[Wan's ShapeMiner]§r";
const MIN_Y = -64; // Minecraft bedrock level limit
const MAX_Y = 320; // Minecraft max build height
const modes = ["3x3", "5x5", "7x7", "line"];
const tools = {
    hammers: [
        { id: "wan_sm:stone_hammer", durability: 132, canDig7x7: false, lineLength: 5 },
        { id: "wan_sm:iron_hammer", durability: 251, canDig7x7: false, lineLength: 10 },
        { id: "wan_sm:gold_hammer", durability: 33, canDig7x7: false, lineLength: 7 },
        { id: "wan_sm:diamond_hammer", durability: 1562, canDig7x7: true, lineLength: 20 },
        { id: "wan_sm:netherite_hammer", durability: 2032, canDig7x7: true, lineLength: 30 }
    ]
};
// Store player preferences
const playerToolModes = new Map();
// Non-breakable blocks
const protectedBlocks = new Set([
    "minecraft:bedrock",
    "minecraft:barrier",
    "minecraft:command_block",
    "minecraft:structure_block",
    "minecraft:structure_void",
    "minecraft:spawner",
]);
// Ore blocks mapping for drop handling
const ORE_BLOCKS = {
    "minecraft:coal_ore": ["minecraft:coal", [1, 1]],
    "minecraft:copper_ore": ["minecraft:raw_copper", [2, 5]],
    "minecraft:iron_ore": ["minecraft:raw_iron", [1, 1]],
    "minecraft:gold_ore": ["minecraft:raw_gold", [1, 1]],
    "minecraft:lapis_ore": ["minecraft:lapis_lazuli", [4, 9]],
    "minecraft:diamond_ore": ["minecraft:diamond", [1, 1]],
    "minecraft:emerald_ore": ["minecraft:emerald", [1, 1]],
    "minecraft:nether_quartz_ore": ["minecraft:quartz", [1, 1]],
    "minecraft:redstone_ore": ["minecraft:redstone", [4, 5]],
    "minecraft:nether_gold_ore": ["minecraft:gold_nugget", [2, 6]],
    "minecraft:ancient_debris": ["minecraft:ancient_debris", [1, 1]],
    "minecraft:deepslate_coal_ore": ["minecraft:coal", [1, 1]],
    "minecraft:deepslate_copper_ore": ["minecraft:raw_copper", [2, 5]],
    "minecraft:deepslate_iron_ore": ["minecraft:raw_iron", [1, 1]],
    "minecraft:deepslate_gold_ore": ["minecraft:raw_gold", [1, 1]],
    "minecraft:deepslate_lapis_ore": ["minecraft:lapis_lazuli", [4, 9]],
    "minecraft:deepslate_diamond_ore": ["minecraft:diamond", [1, 1]],
    "minecraft:deepslate_emerald_ore": ["minecraft:emerald", [1, 1]],
    "minecraft:deepslate_redstone_ore": ["minecraft:redstone", [4, 5]],
};
// Special drop blocks that need different drop item when broken without Silk Touch
const SPECIAL_DROP_BLOCKS = {
    "minecraft:stone": "minecraft:cobblestone",
    "minecraft:deepslate": "minecraft:cobbled_deepslate",
    "minecraft:grass_block": "minecraft:dirt",
    "minecraft:mycelium": "minecraft:dirt",
    "minecraft:podzol": "minecraft:dirt",
    "minecraft:clay": "minecraft:clay_ball", // Drops 4 clay balls
    "minecraft:bookshelf": "minecraft:book", // Drops 3 books
    "minecraft:snow_block": "minecraft:snowball", // Drops 4 snowballs
    "minecraft:glowstone": "minecraft:glowstone_dust", // Drops 2-4 glowstone dust
    "minecraft:gravel": "minecraft:flint", // Has a chance to drop flint
    "minecraft:crimson_nylium": "minecraft:netherrack",
    "minecraft:warped_nylium": "minecraft:netherrack",
    "minecraft:ice": null, // Drops nothing without Silk Touch
    "minecraft:packed_ice": "minecraft:ice",
    "minecraft:blue_ice": "minecraft:packed_ice",
    "minecraft:sea_lantern": "minecraft:prismarine_crystals", // Drops 2-3 prismarine crystals
    "minecraft:infested_stone": null, // Infested blocks drop nothing
    "minecraft:infested_cobblestone": null,
    "minecraft:infested_stone_bricks": null,
    "minecraft:infested_mossy_stone_bricks": null,
    "minecraft:infested_cracked_stone_bricks": null,
    "minecraft:infested_chiseled_stone_bricks": null,
    "minecraft:infested_deepslate": null,
};
// Special drop blocks that need multiple items
const MULTIPLE_DROP_BLOCKS = {
    "minecraft:clay": ["minecraft:clay_ball", 4],
    "minecraft:bookshelf": ["minecraft:book", 3],
    "minecraft:snow_block": ["minecraft:snowball", 4],
    "minecraft:glowstone": ["minecraft:glowstone_dust", [2, 4]],
    "minecraft:sea_lantern": ["minecraft:prismarine_crystals", [2, 3]],
};
function getToolDetails(itemId) {
    const hammer = tools.hammers.find(h => h.id === itemId);
    if (hammer)
        return { ...hammer, type: "hammer" };
    return null;
}
function getToolMode(player, toolId) {
    const playerId = player.id;
    if (!playerToolModes.has(playerId)) {
        playerToolModes.set(playerId, {});
    }
    const playerModes = playerToolModes.get(playerId);
    if (!playerModes[toolId]) {
        playerModes[toolId] = "3x3";
    }
    return playerModes[toolId];
}
function cycleToolMode(player, toolDetails) {
    const playerId = player.id;
    const toolId = toolDetails.id;
    const currentMode = getToolMode(player, toolId);
    let nextIndex = (modes.indexOf(currentMode) + 1) % modes.length;
    if (modes[nextIndex] === "7x7" && !toolDetails.canDig7x7) {
        nextIndex = (nextIndex + 1) % modes.length;
    }
    const nextMode = modes[nextIndex];
    playerToolModes.get(playerId)[toolId] = nextMode;
    // Update message with caps at start and addon prefix
    player.sendMessage(`${ADDON_PREFIX} Mode changed to: §e${nextMode}`);
}
function showToolInfo(player) {
    const heldItem = player.getComponent("equippable")?.getEquipment(EquipmentSlot.Mainhand);
    if (!heldItem)
        return;
    const toolDetails = getToolDetails(heldItem.typeId);
    if (!toolDetails)
        return;
    const currentMode = getToolMode(player, toolDetails.id);
    const durabilityComponent = heldItem.getComponent("minecraft:durability");
    if (!durabilityComponent)
        return;
    const maxDurability = toolDetails.durability;
    const currentDamage = durabilityComponent.damage;
    const durabilityLeft = maxDurability - currentDamage;
    const durabilityPercentage = Math.floor((durabilityLeft / maxDurability) * 100);
    let durabilityColor = "§a";
    if (durabilityPercentage < 25)
        durabilityColor = "§c";
    else if (durabilityPercentage < 50)
        durabilityColor = "§e";
    // Mode display adjustments for Line mode to show length
    const modeDisplay = currentMode === "line" ?
        `line x${toolDetails.lineLength}` : currentMode;
    if (durabilityLeft < 9) {
        player.onScreenDisplay.setActionBar(`§cWARNING! §r§7| §eRepair with a hammer of same tier §7| §6[${durabilityLeft}/${maxDurability}]`);
    }
    else {
        player.onScreenDisplay.setActionBar(`§6[Mode]§r §e${modeDisplay}  §7|  §6[Durability]§r ${durabilityColor}${durabilityLeft}/${maxDurability}`);
    }
}
function getPlayerFacingDirection(player) {
    const viewVector = player.getViewDirection();
    const absX = Math.abs(viewVector.x);
    const absY = Math.abs(viewVector.y);
    const absZ = Math.abs(viewVector.z);
    if (absY > absX && absY > absZ) {
        return viewVector.y > 0 ? "up" : "down";
    }
    else if (absZ > absX) {
        return viewVector.z > 0 ? "south" : "north";
    }
    else {
        return viewVector.x > 0 ? "east" : "west";
    }
}
function isValidAndBreakable(dimension, pos) {
    // Check if position is within world boundaries
    if (pos.y < MIN_Y || pos.y > MAX_Y)
        return false;
    const block = dimension.getBlock(pos);
    if (!block || block.typeId === "minecraft:air")
        return false;
    // Check if block is in the protected list
    if (protectedBlocks.has(block.typeId))
        return false;
    return true;
}
function getBreakPositions(startPos, radius, face) {
    const positions = [];
    // Determine which axes to iterate based on the face
    let iter1, iter2;
    if (face === "up" || face === "down") {
        // For up/down faces, iterate X and Z
        iter1 = { axis: "x", min: -radius, max: radius };
        iter2 = { axis: "z", min: -radius, max: radius };
    }
    else if (face === "north" || face === "south") {
        // For north/south faces, iterate X and Y
        iter1 = { axis: "x", min: -radius, max: radius };
        iter2 = { axis: "y", min: -radius, max: radius };
    }
    else {
        // For east/west faces, iterate Y and Z
        iter1 = { axis: "y", min: -radius, max: radius };
        iter2 = { axis: "z", min: -radius, max: radius };
    }
    // Generate all positions in the shape
    for (let i = iter1.min; i <= iter1.max; i++) {
        for (let j = iter2.min; j <= iter2.max; j++) {
            const pos = { ...startPos }; // Clone start position
            // Apply offsets based on the axes we're iterating
            if (iter1.axis === "x")
                pos.x += i;
            else if (iter1.axis === "y")
                pos.y += i;
            else
                pos.z += i;
            if (iter2.axis === "x")
                pos.x += j;
            else if (iter2.axis === "y")
                pos.y += j;
            else
                pos.z += j;
            // Ensure we use integer coordinates
            pos.x = Math.floor(pos.x);
            pos.y = Math.floor(pos.y);
            pos.z = Math.floor(pos.z);
            positions.push(pos);
        }
    }
    return positions;
}
// Helper function to generate random number within range
function random(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}
function breakBlockWithDrops(dimension, pos, player, itemStack) {
    if (!isValidAndBreakable(dimension, pos))
        return false;
    const block = dimension.getBlock(pos);
    if (!block)
        return false;
    const blockTypeId = block.typeId;
    const blockPermutation = block.permutation;
    // Skip drops in Creative mode
    const isCreative = player.getGameMode() === GameMode.creative;
    // Get enchantment levels if not in creative mode
    const enchants = !isCreative ? itemStack.getComponent("minecraft:enchantable") : null;
    const hasSilkTouch = enchants?.getEnchantment("minecraft:silk_touch")?.level > 0 || false;
    const fortuneLevel = enchants?.getEnchantment("minecraft:fortune")?.level || 0;
    // Only handle drops if not in creative mode
    if (!isCreative) {
        // Check if it's an ore block that needs special drop handling
        if (ORE_BLOCKS[blockTypeId]) {
            const [dropItem, dropRange] = ORE_BLOCKS[blockTypeId];
            // Calculate drop amount based on Fortune
            const baseAmount = random(dropRange[0], dropRange[1]);
            const dropAmount = hasSilkTouch ? 1 : Math.max(1, baseAmount * (fortuneLevel > 0 ? fortuneLevel + 1 : 1));
            // Create the drop item
            const dropItemStack = new ItemStack(hasSilkTouch ? blockTypeId : dropItem, hasSilkTouch ? 1 : dropAmount);
            // Spawn the drops
            dimension.spawnItem(dropItemStack, pos);
            // Spawn XP orbs for ores with Fortune
            if (fortuneLevel > 0 && !hasSilkTouch) {
                for (let i = 0; i < Math.min(dropAmount, 5); i++) {
                    dimension.spawnEntity('minecraft:xp_orb', pos);
                }
            }
        }
        // Handle blocks with multiple drops
        else if (MULTIPLE_DROP_BLOCKS[blockTypeId] && !hasSilkTouch) {
            const [dropItem, amount] = MULTIPLE_DROP_BLOCKS[blockTypeId];
            let dropAmount;
            // Check if the amount is a range or fixed number
            if (Array.isArray(amount)) {
                dropAmount = random(amount[0], amount[1]);
            }
            else {
                dropAmount = amount;
            }
            // Spawn the drops
            const dropItemStack = new ItemStack(dropItem, dropAmount);
            dimension.spawnItem(dropItemStack, pos);
        }
        // Handle special drop blocks
        else if (SPECIAL_DROP_BLOCKS[blockTypeId] !== undefined) {
            if (hasSilkTouch) {
                // With Silk Touch, drop the original block
                const itemStack = blockPermutation.getItemStack();
                if (itemStack) {
                    dimension.spawnItem(itemStack, pos);
                }
            }
            else if (SPECIAL_DROP_BLOCKS[blockTypeId] !== null) {
                // Without Silk Touch, drop the special item
                const dropItemStack = new ItemStack(SPECIAL_DROP_BLOCKS[blockTypeId], 1);
                dimension.spawnItem(dropItemStack, pos);
            }
            // If null, drop nothing (ice, spawner, etc.)
        }
        // For regular blocks
        else {
            // Drop the regular block item
            const itemStack = blockPermutation.getItemStack();
            if (itemStack) {
                dimension.spawnItem(itemStack, pos);
            }
        }
    }
    // Set the block to air (break it)
    block.setType("minecraft:air");
    return true;
}
function breakBlocksInArea(dimension, startPos, mode, face, player, itemStack) {
    const radius = mode === "3x3" ? 1 : mode === "5x5" ? 2 : 3;
    let blocksDestroyed = 0;
    // Get positions in the proper shape based on the face
    const positions = getBreakPositions(startPos, radius, face);
    // Break blocks at all valid positions
    for (const pos of positions) {
        if (breakBlockWithDrops(dimension, pos, player, itemStack)) {
            blocksDestroyed++;
        }
    }
    return blocksDestroyed;
}
function breakBlocksInLine(dimension, startPos, face, lineLength, player, itemStack) {
    let blocksDestroyed = 0;
    let dx = 0, dy = 0, dz = 0;
    switch (face) {
        case "north":
            dz = -1;
            break;
        case "south":
            dz = 1;
            break;
        case "east":
            dx = 1;
            break;
        case "west":
            dx = -1;
            break;
        case "up":
            dy = 1;
            break;
        case "down":
            dy = -1;
            break;
    }
    // Break blocks in line
    for (let i = 0; i < lineLength; i++) {
        const pos = {
            x: Math.floor(startPos.x + dx * i),
            y: Math.floor(startPos.y + dy * i),
            z: Math.floor(startPos.z + dz * i)
        };
        if (breakBlockWithDrops(dimension, pos, player, itemStack)) {
            blocksDestroyed++;
        }
    }
    // Break blocks below for horizontal mining (1x2x10 pattern)
    if (["north", "south", "east", "west"].includes(face)) {
        for (let i = 0; i < lineLength; i++) {
            const pos = {
                x: Math.floor(startPos.x + dx * i),
                y: Math.floor(startPos.y - 1),
                z: Math.floor(startPos.z + dz * i)
            };
            if (breakBlockWithDrops(dimension, pos, player, itemStack)) {
                blocksDestroyed++;
            }
        }
    }
    return blocksDestroyed;
}
function mineMultipleBlocks(player, blockPos, face) {
    const heldItem = player.getComponent("equippable")?.getEquipment(EquipmentSlot.Mainhand);
    if (!heldItem)
        return;
    const toolDetails = getToolDetails(heldItem.typeId);
    if (!toolDetails)
        return;
    const currentMode = getToolMode(player, toolDetails.id);
    if (currentMode === "7x7" && !toolDetails.canDig7x7) {
        player.sendMessage(`${ADDON_PREFIX} This hammer cannot use 7x7 mode. Reverting to 3x3.`);
        playerToolModes.get(player.id)[toolDetails.id] = "3x3";
        return;
    }
    const dimension = player.dimension;
    const isCreative = player.getGameMode() === GameMode.creative;
    // In creative mode, just break blocks without handling durability
    if (isCreative) {
        if (currentMode !== "line") {
            breakBlocksInArea(dimension, blockPos, currentMode, face, player, heldItem);
        }
        else {
            breakBlocksInLine(dimension, blockPos, face, toolDetails.lineLength, player, heldItem);
        }
        return;
    }
    // Get durability component
    const durabilityComponent = heldItem.getComponent("minecraft:durability");
    if (!durabilityComponent)
        return;
    const maxDurability = toolDetails.durability;
    const currentDamage = durabilityComponent.damage;
    const durabilityLeft = maxDurability - currentDamage;
    // If we're about to break the tool with the last durability point
    if (durabilityLeft <= 1) {
        player.playSound("random.break");
        player.getComponent("equippable")?.setEquipment(EquipmentSlot.Mainhand, null);
        return;
    }
    // Break blocks and count how many were actually destroyed
    let damageCount = 0;
    if (currentMode !== "line") {
        damageCount = breakBlocksInArea(dimension, blockPos, currentMode, face, player, heldItem);
    }
    else {
        damageCount = breakBlocksInLine(dimension, blockPos, face, toolDetails.lineLength, player, heldItem);
    }
    if (damageCount <= 0)
        return;
    // Apply Unbreaking enchantment
    const unbreakingLevel = getUnbreakingLevel(heldItem);
    const actualDamage = calculateDamageReduction(unbreakingLevel, damageCount);
    // If the remaining durability is not enough
    if (actualDamage >= durabilityLeft) {
        player.playSound("random.break");
        player.getComponent("equippable")?.setEquipment(EquipmentSlot.Mainhand, null);
    }
    else {
        durabilityComponent.damage = currentDamage + actualDamage + 1;
        player.getComponent("equippable")?.setEquipment(EquipmentSlot.Mainhand, heldItem);
    }
}
// Get Unbreaking enchantment level
function getUnbreakingLevel(itemStack) {
    try {
        const unbLevel = itemStack.getComponent("minecraft:enchantable")?.getEnchantment("unbreaking")?.level;
        return unbLevel ?? 0; // Return the level or 0 if undefined
    }
    catch (err) {
        // If the enchantment type or something else doesn't exist, consider level 0
        return 0;
    }
}
// Given an original request of 'origDamage' points, calculates how many points should actually be deducted
function calculateDamageReduction(unbreakingLevel, origDamage) {
    if (unbreakingLevel <= 0)
        return origDamage;
    let reduced = 0;
    const chance = 1 / (unbreakingLevel + 1);
    for (let i = 0; i < origDamage; i++) {
        if (Math.random() < chance)
            reduced++;
    }
    return reduced;
}
function initialize() {
    world.afterEvents.itemUse.subscribe((event) => {
        const player = event.source;
        if (player instanceof Player && player.isSneaking) {
            const item = event.itemStack;
            const td = getToolDetails(item.typeId);
            if (td) {
                cycleToolMode(player, td);
            }
        }
    });
    world.afterEvents.playerBreakBlock.subscribe((event) => {
        const player = event.player;
        if (!player)
            return;
        const block = event.block;
        if (!block)
            return;
        const face = getPlayerFacingDirection(player);
        mineMultipleBlocks(player, block.location, face);
    });
    system.runInterval(() => {
        for (const player of world.getPlayers()) {
            showToolInfo(player);
        }
    }, 5);
    world.sendMessage(`${ADDON_PREFIX} Addon successfully loaded!`);
}
initialize();
